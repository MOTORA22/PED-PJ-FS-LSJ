window.addEventListener("DOMContentLoaded", function () {

    const mas = document.querySelector("#oh");
    console.log(mas);
    
    setTimeout(() => mas.style.overflow="visible", 3000);
});